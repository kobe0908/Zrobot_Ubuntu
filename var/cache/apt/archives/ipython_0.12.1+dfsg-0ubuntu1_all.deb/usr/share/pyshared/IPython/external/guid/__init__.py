try:
    from guid import *
except ImportError:
    from _guid import *
