try:
    from mglob import *
except ImportError:
    from _mglob import *
