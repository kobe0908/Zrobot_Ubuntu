#!/bin/sh
echo testtesttest > ./tmp.txt
