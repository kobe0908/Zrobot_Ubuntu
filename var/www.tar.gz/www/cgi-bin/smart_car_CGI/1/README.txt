The source codes in this folder are working as cgi-bin in website.
After compile with Cross-compiler then copy them into linaro_ubuntu's filesystem /var/www/cgi-bin
Please use "make" command to compile them. (Please modfiy CROSS-COMPILER to your path)
Enjoy!

XUP team
2013/3/6

